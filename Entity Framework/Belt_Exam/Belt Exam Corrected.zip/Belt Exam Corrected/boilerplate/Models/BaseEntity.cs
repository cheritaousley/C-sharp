namespace boilerplate.Models
{
    public abstract class BaseEntity { }
}