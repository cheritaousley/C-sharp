namespace restaurant.Models
{
    public abstract class BaseEntity { }
}