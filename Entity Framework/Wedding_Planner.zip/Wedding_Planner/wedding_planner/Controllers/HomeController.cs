using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
//adding Entity Framework//
using Microsoft.EntityFrameworkCore;
using wedding_planner.Models;
using System.Linq;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Identity; //for hashing password

namespace wedding_planner.Controllers
{
    public class HomeController : Controller
    {
        private WeddingContext _context;
        public HomeController(WeddingContext context)
        {
            _context = context;
        }

        // GET: /Home/
        [HttpGet]
        [Route("")]
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [Route("create")]
        public IActionResult create(RegisterViewModel reguser)  //this will hold what the user enters
        {
            User NewUser = new User   //new user is the package semdimg to the database//this is what is being sent by to the database
            {
                first_name = reguser.first_name,
                last_name = reguser.last_name,
                username = reguser.username,
                age = reguser.age,
                email = reguser.email,
                password = reguser.password
            };
            if (TryValidateModel(NewUser))
            {
                if (NewUser.password == reguser.confirm_password)
                {
                    PasswordHasher<RegisterViewModel> Hasher = new PasswordHasher<RegisterViewModel>();
                    NewUser.password = Hasher.HashPassword(reguser, NewUser.password);
                    _context.user.Add(NewUser);
                    _context.SaveChanges();
                    HttpContext.Session.SetInt32("loggedUserID", reguser.id);
                    HttpContext.Session.SetString("loggedUser", reguser.first_name);
                }
                return RedirectToAction("Success");
            }
            else
            {
                ViewBag.errors = ModelState.Values;
                System.Console.WriteLine("=============================");
                System.Console.WriteLine(ViewBag.errors);
                System.Console.WriteLine("=============================");

            }
            ViewBag.login_user = reguser.first_name;
            return View("Index");
        }

        [HttpPost]
        [Route("login")]
        public IActionResult Login(LoginViewModel loguser)//this is saying look for an input from a form named "Email", so either change this name or change the form
        {
            User login_user = _context.user.SingleOrDefault(user => user.email == loguser.loginEmail);
            if (login_user != null)
            {
                PasswordHasher<LoginViewModel> Hasher = new PasswordHasher<LoginViewModel>();
                if (Hasher.VerifyHashedPassword(loguser, login_user.password, loguser.loginPassword) != 0)
                {
                    HttpContext.Session.SetInt32("loggedUserID", login_user.id);
                    HttpContext.Session.SetString("loggedEmail", loguser.loginEmail);
                    HttpContext.Session.SetString("loggedUser", login_user.first_name);
                }
                else
                {
                    ViewBag.fail = "User does not exist";
                    return View("logUser");
                }
            }
            else
            {
                ViewBag.fail = "Fields cannot be blank!";
            }
            ViewBag.login_user = login_user.first_name;
            return RedirectToAction("Success");
            // if(login_user.email == loguser.loginEmail)
            // {
            //     return View("Success");
            // }

        }

        [HttpGet]
        [Route("logUser")]
        public IActionResult LogUser(LoginViewModel loguser)
        {
            return View("LogUser");
        }

        [HttpGet]
        [Route("dashboard")]
        public IActionResult Success()
        {

            List<User> AllUsers = _context.user.ToList();
            List<Wedding> AllWeddings = _context.wedding.ToList();
            ViewBag.users = AllUsers;
            ViewBag.weddings = AllWeddings;
            ViewBag.login_user = HttpContext.Session.GetString("loggedUser"); //remember view bags does not exist over redirects! so must call on that session (using Get) when i am ready to view that variable
            ViewBag.User = HttpContext.Session.GetInt32("loggedUserID");
            return View("Success");
        }

        [HttpPost]
        [Route("createwedding")]
        public IActionResult CreateWedding(WeddingViewModel weddingPlan)
        {
            int? login_user = HttpContext.Session.GetInt32("loggedUserID");  //this two step process is to check to see if there is a logged in user. This ideally should be done whenever you render a new page
            User loggedUserID = _context.user.SingleOrDefault(_user => _user.id ==login_user);
            if(loggedUserID != null)
            {
                Wedding NewWedding = new Wedding
                {
                    Bride = weddingPlan.Bride,
                    Groom = weddingPlan.Groom,
                    Date = weddingPlan.Date,
                    Address = weddingPlan.Address,
                    user_id = loggedUserID.id, 

                };

                if (TryValidateModel(NewWedding))
                {
                    _context.wedding.Add(NewWedding);
                    _context.SaveChanges();
                    return RedirectToAction("Success");

                }
                else
                {
                    ViewBag.errors = ModelState.Values;
                    return View("AddWedding");
                }
            }
           else
           {
               ViewBag.errors = ModelState.Values;
               return View("AddWedding");
           }
        }

        [HttpGet]
        [Route("plan")]
        public IActionResult AddWedding()
        {
            return View("AddWedding");
        }

        [HttpGet]
        [Route("viewWedding/{wedding_id}")]
        public IActionResult ViewWedding(int wedding_id)
        {
            List<User> AllUsers = _context.user.ToList(); //must pass these two list in this route to in order to render it
            List<Wedding> AllWeddings = _context.wedding.ToList();
            List<Guest> AllGuests = _context.guest.Include(guest_name => guest_name.User).ToList();
            ViewBag.guests = AllGuests;
            ViewBag.weddings = AllWeddings;
            ViewBag.wedding_party = _context.wedding.SingleOrDefault(wedding => wedding.id == wedding_id);
            return View("ViewWedding");
        }

        [HttpGet]
        [Route("delete")]
        public IActionResult DeleteWedding()
        {
            return RedirectToAction("ViewWedding");
        }

        [HttpGet]
        [Route("rsvp/{wedding_id}")]
        public IActionResult RSVP(GuestViewModel guest_attending, int wedding_id)
        {
            int? login_user = HttpContext.Session.GetInt32("loggedUserID"); 
            User loggedUserID = _context.user.SingleOrDefault(_user => _user.id == login_user);
            Wedding wedding_chosen = _context.wedding.SingleOrDefault(wedding =>wedding.id== wedding_id);
            Guest NewGuest = new Guest
            {
               Name = guest_attending.Name,
               user_id = loggedUserID.id,
               wedding_id = wedding_chosen.id,
               User = loggedUserID,  //in order to have access to this information in the user object, must pass this in
               Wedding = wedding_chosen

            };
            _context.guest.Add(NewGuest);
            _context.SaveChanges();
            return RedirectToAction("ViewWedding", new{wedding_id=wedding_id});
        }

        [HttpGet]
        [Route("unrsvp/{wedding_id}/{user_id}")]
        public IActionResult UNRSVP(int wedding_id, int user_id)
        {
            int? login_user = HttpContext.Session.GetInt32("loggedUserID");
            Wedding current_wedding = _context.wedding.SingleOrDefault(w => w.id == wedding_id);
            List <Guest> allGuest = _context.guest.Where(_guest => _guest.wedding_id == current_wedding.id).ToList();
            Guest deleted_guest = allGuest.SingleOrDefault(g => g.user_id == login_user);
            _context.guest.Remove(deleted_guest);
            _context.SaveChanges();
            return RedirectToAction("Success");
        }

        [HttpGet]
        [Route("logout")]
        public IActionResult logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index");
        }
    }
}
