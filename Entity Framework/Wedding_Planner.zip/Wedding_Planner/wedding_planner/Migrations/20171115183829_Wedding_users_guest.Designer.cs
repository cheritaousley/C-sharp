﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using wedding_planner.Models;

namespace wedding_planner.Migrations
{
    [DbContext(typeof(WeddingContext))]
    [Migration("20171115183829_Wedding_users_guest")]
    partial class Wedding_users_guest
    {
        protected override void BuildTargetModel(ModelBuilder modelBuilder)
        {
            modelBuilder
                .HasAnnotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn)
                .HasAnnotation("ProductVersion", "1.1.2");

            modelBuilder.Entity("wedding_planner.Models.Guest", b =>
                {
                    b.Property<int>("id")
                        .ValueGeneratedOnAdd();

                    b.Property<int?>("Userid");

                    b.Property<int?>("Weddingid");

                    b.Property<int>("user_id");

                    b.Property<int>("wedding_id");

                    b.HasKey("id");

                    b.HasIndex("Userid");

                    b.HasIndex("Weddingid");

                    b.ToTable("guest");
                });

            modelBuilder.Entity("wedding_planner.Models.User", b =>
                {
                    b.Property<int>("id")
                        .ValueGeneratedOnAdd();

                    b.Property<int>("age");

                    b.Property<string>("email")
                        .IsRequired();

                    b.Property<string>("first_name")
                        .IsRequired();

                    b.Property<string>("last_name")
                        .IsRequired();

                    b.Property<string>("password")
                        .IsRequired();

                    b.Property<string>("username")
                        .IsRequired();

                    b.HasKey("id");

                    b.ToTable("user");
                });

            modelBuilder.Entity("wedding_planner.Models.Wedding", b =>
                {
                    b.Property<int>("id")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("Address");

                    b.Property<string>("Bride");

                    b.Property<DateTime>("Date");

                    b.Property<string>("Groom");

                    b.Property<int>("Guest_expected");

                    b.Property<int?>("Userid");

                    b.Property<int>("user_id");

                    b.HasKey("id");

                    b.HasIndex("Userid");

                    b.ToTable("wedding");
                });

            modelBuilder.Entity("wedding_planner.Models.Guest", b =>
                {
                    b.HasOne("wedding_planner.Models.User", "User")
                        .WithMany()
                        .HasForeignKey("Userid");

                    b.HasOne("wedding_planner.Models.Wedding", "Wedding")
                        .WithMany("Guest")
                        .HasForeignKey("Weddingid");
                });

            modelBuilder.Entity("wedding_planner.Models.Wedding", b =>
                {
                    b.HasOne("wedding_planner.Models.User", "User")
                        .WithMany("Wedding")
                        .HasForeignKey("Userid");
                });
        }
    }
}
