namespace wedding_planner.Models
{
    public abstract class BaseEntity { }
}