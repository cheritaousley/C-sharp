using Microsoft.EntityFrameworkCore;

namespace wedding_planner.Models
{
    public class WeddingContext : DbContext
    {
        // base() calls the parent class' constructor passing the "options" parameter along
        public WeddingContext(DbContextOptions<WeddingContext> options) : base(options) { }
        public DbSet<User> user { get; set; }
        public DbSet<Wedding> wedding { get; set; }
        public DbSet<Guest> guest { get; set; }
    }
}