using System.ComponentModel.DataAnnotations;
using System;
using System.Text.RegularExpressions;
using System.Collections.Generic;

namespace wedding_planner.Models
{
    public class Wedding
    {
        public int id { get; set; }
        public string Bride { get; set; }
        public string Groom { get; set; }
        public DateTime Date { get; set; }
        public string Address{ get; set; }
        public int user_id { get; set; }
        public User User { get; set; }
        public List<Guest> Guest { get; set; }
    }
    public class WeddingViewModel : BaseEntity
    {
        [Key]
        public int id { get; set; }

        [Required]
        [MinLength(3)]
        public string Bride { get; set; }

        [Required]
        [MinLength(3)]
        public string Groom { get; set; }

        [Required]
        [DataType(DataType.Date)]
        public DateTime Date { get; set; }

        [Required]
        [MinLength(3)]
        public string Address { get; set; }

        [Required]
        public int user_id { get; set; }
        public User User { get; set; }
    }
    public class WeddingGuestViewModel : BaseEntity
    {
        public WeddingViewModel weddingVM { get; set; } //adding these two models in a wrapper allows me to see all the data on the same page
        public GuestViewModel  guestVM { get; set;}
        public List<Guest> Guest { get; set; }
    }
}
