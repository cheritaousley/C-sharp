using System.ComponentModel.DataAnnotations;
using System;
using System.Text.RegularExpressions;


namespace wedding_planner.Models
{
    public class Guest
    {
        public int id { get; set; }
        public string Name { get; set;}
        public int user_id { get; set; }
        public User User { get; set; }
        public int wedding_id { get; set; }
        public Wedding Wedding { get; set; }
    }
    public class GuestViewModel : BaseEntity
    {
        [Key]
        public int id { get; set; }

        [Required]
        [MinLength(3)]
        public string Name { get; set; }
    }
}
