namespace bank_account.Models
{
    public abstract class BaseEntity { }
}