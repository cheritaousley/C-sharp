﻿using System;
using DbConnection;
using System.Collections.Generic;

namespace Simple_CRUD
{
    class Program
    {
        static public void Read()
        {
            List<Dictionary<string, object>> userInfo = DbConnector.Query("SELECT FirstName as 'First Name', LastName as 'Last Name', FavoriteNum as 'Favorite Number' from User");
            Console.WriteLine("User Information as follows:");
            foreach (var info in userInfo)
            {
                foreach (KeyValuePair<string, object> user in info)
                    Console.Write("{user.Key}: {user.Value}" + "");
            }
            Console.WriteLine();
        }
        static public void Create()
        {
            string first = Console.ReadLine();
            string last = Console.ReadLine();
            string number = Console.ReadLine();

            // string first = "first";//Console.ReadLine();
            // string last = "last"; //Console.ReadLine();
            // string number = "10";//Console.ReadLine();

            string x= $"INSERT INTO User(firstName, lastName, favoriteNum) VALUES('{first}', '{last}', '{number}')";
            System.Console.WriteLine(x);
            DbConnector.Execute(x);
        }  
        static void Main(string[] args)
        {
            // string InputLine = Console.ReadLine();
            // DbConnector.Query("Some query string expecting data returned");
            Read();
            Create();
        }

        }
}
