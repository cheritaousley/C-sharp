using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using form_app.Models;
// using DbConnection;

namespace form_app.Controllers
{
    public class UsersController : Controller
    {
        // GET: /Home/
        [HttpGet]
        [Route("")]
        public IActionResult Index()
        {
            if(ViewBag.Errors == null)
            {

            }
            return View("Index");
        }
        [HttpPost]
        [Route("success")]
        public IActionResult success(string fname, string lname, int age, string Email, string Password)
        {
            User NewUser = new User(fname, lname, age, Email, Password);
            TryValidateModel(NewUser);
            ViewBag.errors = ModelState.Values;
            return View("success");
        }

    }
}
