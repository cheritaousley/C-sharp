using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using users_app.Models;
using Newtonsoft.Json;

namespace users_app.Controllers
{
    public class HomeController : Controller
    {
        private readonly DbConnector _dbConnector;

        public HomeController(DbConnector connect)
        {
            _dbConnector = connect;
        }

        [HttpGet]
        [Route("")]
        public IActionResult Index()
        {
            return View("Index");
        }
        [HttpPost]
        [Route("create")]
        public IActionResult create(string first_name, string last_name, int age, string email, string password, string confirm_password) //pulling information from the form
        {
            User NewUser = new User(first_name, last_name, age, email, password, confirm_password);
            string strNewUser = JsonConvert.SerializeObject(NewUser);  //changing object NewUser to a string via serial
            HttpContext.Session.SetString("UserKey", strNewUser); //storing now string NewUser into session
            
            if(TryValidateModel(NewUser))
            {
                string query = $"INSERT INTO User(first_name, last_name, age, email, password) VALUES('{first_name}','{last_name}','{age}','{email}', '{password}')";
                _dbConnector.Execute(query);
                ViewBag.userCreated =first_name;
                return View("success");   //Should always redirect in post route, and you can only use tempData to store info in btw routes
            }
            else
            {
                ViewBag.errors = ModelState.Values;
            }
                return View("Index");           //why arent we redirecting again? To keep form entries filled AND present errors
        }
        [HttpGet]
        [Route("success")]
        public IActionResult success(string first_name, string last_name, int age, string email, string password, string confirm_password) //this is pulling from the form
        {
            return View("success");
        }
        [HttpPost]
        [Route("login")]
        public IActionResult login(string email, string password) 
        {
            string selectquery = $"SELECT * from User where email = '{email}'"; //creating the query as a string
            List<Dictionary<string, object>> result = _dbConnector.Query(selectquery); //executing the query and stored in 'result' as a list of dictionaries
            var user = result[0]; 
            if((string) user["password"] == password)
            {
                int user_id = (int)user["id"]; //This is how we grab it from the database . Grabbing a piece from the dictionary//these are the internal variable, the values
                string _firstname = (string) user["first_name"];
                HttpContext.Session.SetInt32("logUser", user_id); //session is global i can grab it via any route, as long as this user is ligged in
                HttpContext.Session.SetString("firstname", _firstname); //since it's already in session, no need to ViewBag it. It can be viewed by calling on it in the cshtml by context.session.getstring
                HttpContext.Session.SetString("userEmail", email);
                Console.WriteLine("-----------------------------------------------");
                System.Console.WriteLine(email);
                System.Console.WriteLine(_firstname);
                System.Console.WriteLine(user_id);
                Console.WriteLine("-----------------------------------------------");
                ViewBag.userCreated = _firstname;
                ViewBag.userEmail = email;
                return View("success");
            }
            else
            {
                ViewBag.fail = "User does not exist";
                return View("logUser");
            }
        }
        [HttpGet]
        [Route("logUser")]
        public IActionResult logUser(string email, string password, int id)
        {
            return View("logUser");
        }
        [HttpGet]
        [Route("theWall")]
        public IActionResult theWall()
        {
            int? user_id = HttpContext.Session.GetInt32("logUser");
            string selectquery = $"SELECT first_name from User where id = '{user_id}'";
            List<Dictionary<string, object>> user_result = _dbConnector.Query(selectquery); //pass this result in as a variable to call on the results later
            Dictionary<string, object> _user = user_result[0];
            string mes_query = $"SELECT message, id from messages";
            List<Dictionary<string, object>> mes_result = _dbConnector.Query(mes_query);   //pass this result in as a variable to call on the results later
            // var _message = mes_result[0];
            string com_query = $"SELECT comment, message_id from comments";
            List<Dictionary<string, object>> com_result = _dbConnector.Query(com_query);
    
            Console.WriteLine("-----------------THIS IS THE USER-------------------------");
            Console.WriteLine(_user);
            Console.WriteLine("-----------------THESE ARE THE MESSAGES-------------------------");
            Console.WriteLine(mes_result);
            Console.WriteLine("-----------------THESE ARE THE COMMENTS-------------------------");
            Console.WriteLine(com_result);
            ViewBag.user =_user;
            ViewBag.message = mes_result;
            ViewBag.comments = com_result;
            return View("theWall");
        }
        [HttpPost]
        [Route("createMessage")]
        public IActionResult createMessage(string message)
        {
            int? user_id = HttpContext.Session.GetInt32("logUser");  //go to session, store this value in another internal local variable to call on it in this route//int? unique int type to accept a null value//or use int? = http.context.session.getint32  int user_id = (int) HttpContext.Session.GetInt32("logUser");
            HttpContext.Session.SetString("message", message);
            string query = $"INSERT INTO messages(message, user_id, created_at, updated_at) VALUES('{message}', {user_id}, NOW(), NOW())";
            _dbConnector.Execute(query);
            Console.WriteLine("-----------------THIS IS THE USER-------------------------");
            Console.WriteLine(user_id);
            Console.WriteLine("-----------------THIS IS THE USER'S MESSAGES-------------------------");
            Console.WriteLine(message);
            return RedirectToAction("theWall");

        }
        [HttpPost]
        [Route("createComment")]
        public IActionResult createComment(string message, string comment, int message_id)
        {
            int? user_id = HttpContext.Session.GetInt32("logUser");  //go to session, store this value in another internal local variable to call on it in this route//int? unique int type to accept a null value//or use int? = http.context.session.getint32  int user_id = (int) HttpContext.Session.GetInt32("logUser");
 
            string query = $"INSERT INTO comments(comment, user_id, message_id, created_at, updated_at) VALUES('{comment}', {user_id}, {message_id}, NOW(), NOW())";
            _dbConnector.Execute(query);
            Console.WriteLine("-----------------THIS IS THE USER-------------------------");
            Console.WriteLine(user_id);
            Console.WriteLine("-----------------THIS IS THE MESSAGES BEING COMMENTED ON-------------------------");
            Console.WriteLine(message_id);
            Console.WriteLine("-----------------THIS IS THE USER'S COMMENT-------------------------");
            Console.WriteLine(comment);
            return RedirectToAction("theWall");

        }
        [HttpGet]
        [Route("logout")]
         public IActionResult logout()
         {
             HttpContext.Session.Clear();
             return RedirectToAction("Index");
         }
    }
}
