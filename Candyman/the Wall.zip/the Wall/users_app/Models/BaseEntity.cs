namespace users_app.Models
{
    public abstract class BaseEntity { }
}
